# aci-user

Deploy switches and switch profiles within fabric

## Requirements

Ansible 2.4 

## Role Variables

```yaml
    hostname: '{{ aci_host }}'
    username: '{{ aci_user }}'
    private_key: '{{ aci_user_key }}'
    validate_certs: '{{ apic_validate_certs }}'
    action: deploy # available: deploy, remove, replace
    dc_model_data:
      dc:
        - name: DEV-E2
          region: EMEA
          city: PAR
          pods:
          - number: 1 
            switches:
              - node_id: 101
                ser_num: TEP-1-103
                type: spine
              - node_id: 1001
                ser_num: TEP-1-101
                type: leaf
              - node_id: 1002
                ser_num: TEP-1-102
                type: leaf    
```


## Behaviour

Script will deploy switches based on the input file.
For all switches respective (single as per design) switch profile, switch policy selector profile, interface profile, interface policy selector profile will be created. 


## Example Playbook

Sample playbook to deploy switches.


```yaml
---
- name: Deploy ACI switches 
  hosts:
    - "localhost"
  gather_facts: no

  vars:
    hostname: '{{ aci_host }}'
    username: '{{ aci_user }}'
    private_key: '{{ aci_user_key }}'
    validate_certs: '{{ apic_validate_certs }}'
    dc_model_data:
      dc:
        - name: DEV-E2
          region: EMEA
          city: PAR
          pods:
          - number: 1 
            switches:
              - node_id: 101
                ser_num: TEP-1-103
                type: spine
              - node_id: 1001
                ser_num: TEP-1-101
                type: leaf
              - node_id: 1002
                ser_num: TEP-1-102
                type: leaf    

  tasks:
    - name: deploy switches
      include_role:
        name: ../roles/aci_switch
```

## License

## Author Information

Created by Tomek Zajac (tomasz.zajac@allianz.com).
