# aci_apic

Configure ACI APIC settings


## Requirements

Ansible, python-dateutil, pyopenssl


## Role Variables

### APIC Authentication

| Name                | Default value | Comments                        |
|---------------------|---------------|---------------------------------|
| apic_host           | ---           | APIC IP address or URL          |
| apic_username       | ---           | APIC username                   |
| apic_password       | ---           | APIC user password              |
| apic_validate_certs | no            | SSL certificate validation      |

### Other

## Behaviour

```mermaid
graph TD
A[start] --> | |B[configure APIC system settings]
```


Set the following configuration options as described in role vars file:

  System -> System Settings

    APIC Connectivity Preferences
    Endpoint Controls
      Rogue EP Control
      IP Aging
      EP Loop Protection
    Port Tracking
    Fabric Wide Setting
      Disable Remote EP Learning
      Enforce Subnet Check
      Reallocate Gipo
      Enforce Domain Validation
      Opflex Client Authentication


## Example Playbook

Sample playbook to configure settings listed above.

```yaml
---
- hosts: localhost
  gather_facts: false

  vars:
    aci_host: sandboxapicdc.cisco.com


  tasks:

    - name: Include credentials
      include_vars:
        file: "../secrets/aci.yml"


    - name: Configure system settings
      include_role:
        name: ../roles/aci_apic

```


## License


## Author Information

