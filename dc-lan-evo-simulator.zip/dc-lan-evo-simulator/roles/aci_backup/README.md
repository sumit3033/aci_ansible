# aci_backup

Add Configuration Export/Import policy with remote location and scheduler and use it to handle configuration backups

## Requirements

- ansible, version 3
- SSH or SFTP access to remote storage
- Encryption certificate is configured for admin

## Role Variables

### APIC Authentication

| Name                | Default value                       | Comments
|---------------------|-------------------------------------|----------
| apic_host           | ---                                 | IP address or URL of APIC
| username            | ---                                 | User to configure APIC
| password            | ---                                 | Password of the User
| apic_use_proxy      | no                                  | If to communicate via proxy
| apic_validate_certs | no                                  | If to check SSL Certificate

### Remote Location policy

| Name                | Default value                       | Comments
|---------------------|-------------------------------------|----------
| remote_loc_name     | geo_backup_location                 | Policy name
| remote_loc_proto    | scp                                 | scp, sftp
| remote_loc_addr     | 10.20.30.40                         |
| remote_loc_port     | "22"                                | string!
| remote_loc_path     | /home/user1/aci_backups             | Directory on Remote Location
| remote_loc_user     | user1                               |
| remote_loc_auth     | useSshKeyContents                   |
| remote_loc_key      | ../secrets/insecure_private_key.yml | private key file, vault-encrypted

Note:

> File referenced by input variable `remote_loc_key` shall define variable `my_key` with private key as its value. This file shall be encrypted by ansible-vault. See more details in [README](secrets/README.md) document.

### Scheduler policy, Recuring Window

| Name                | Default value                       | Comments
|---------------------|-------------------------------------|----------
| sched_name          | geo_backup_scheduler                | Policy name
| sched_recurr_win    | geo_recurr_win                      | Recuring Window name
| sched_day           | "1"               # Once a week     | string!
| sched_hour          | "1"                                 | string!
| sched_minute        | "1"                                 | string!
| sched_max_len       | 00:00:02:00.000   # 2 minutes       | Recuring Window timeout

### Export policy

| Name                | Default value                       | Comments
|---------------------|-------------------------------------|----------
| export_policy       | geo_aci_bak_export                  | Policy name
| bak_secrets         | "no"                                | string! To include secrets or not

### Import policy

| Name                | Default value                       | Comments
|---------------------|-------------------------------------|----------
| import_policy       | geo_aci_bak_import                  | Policy name
| backup_file         | ce2_{{ export_policy }}-2020-01-15T13-21-33.tar.gz | Remote backup filename

### Backup Action

| Name                | Default value                       | Comments
|---------------------|-------------------------------------|----------
| backup_action       | create                              | create, trigger_export, import

## Behaviour

```mermaid
graph TD
A[main] --> |validate input parameters| B{backup_action}

B --> |create| C[Create Remote Location]
C --> C1[Create Scheduler]
C1 --> C2[Create Export policy]

B --> |trigger_export| D[Trigger Export policy]
D --> D1[Store a backup]

B --> |import| E[Create Import policy]
E --> E1[Trigger Import policy]
E1 --> E2[Import backup file]
```

Script can execute one of three possible actions:

- **create** - Create Remote Location, Create Scheduler, Create Export policy, if absent
- **trigger_export** - Trigger Export policy to create backup and save it to remote host
- **import** - Create Import policy, import backup file from remote storage

Backup files are stored on Remote Location. Backup can be imported (uploaded) to a local Snapshot. Then actions from role `aci_snapshot` can be applied to it.  
Backup actions like 'list', 'compare', 'delete' are not (?) working with remote storage. One can do this manually on remote host, or it can be automated by script without requesting for ACI Fabric.

## Example Playbook

```yaml
---
- name: Backup configuration
  hosts: [ localhost ]
  gather_facts: no
  vars_files: [ example_vars.yml ]
  tasks:
    - name: Create Remote Location, Create Scheduler, Create Export policy
      include_role: { name: aci_backup }
      vars: { backup_action: create }
    - name: Trigger Export policy, save backup on remote host
      include_role: { name: aci_backup }
      vars: { backup_action: trigger_export }
```

See more details in playbook file [config_backup](playbooks/config_backup.yml)

## Playbook usage examples

Create Remote Location, Scheduler and Configuration Export policies

```bash
ansible-playbook playbooks/config_backup.yml
```

Create backup:

```bash
ansible-playbook playbooks/config_backup.yml -e backup_action=trigger_export
```

Import backup:

```bash
ansible-playbook playbooks/config_backup.yml -e backup_action=import -e backup_file=ce2_geo_aci_bak_export-2020-01-15T13-21-33.tar.gz
```

## License

## Author Information

Created by Georgs Muravjovs (georgs.muravjovs@accenture.com)
