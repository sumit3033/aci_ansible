# aci_snapshot

Add Configuration Export/Import policy and use it to handle snapshots

## Requirements

`ansible`, `jmespath`

Note:

> Python package `jmespath` shall be installed on GitLab Runner host for `python3` and for user `gitlab-runner`.  
Example of the installation command:

```bash
sudo su -s /bin/bash -l gitlab-runner -c "pip3 install jmespath"
```

## Role Variables

### APIC Authentication

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| apic_host           | ---                     | IP address or URL of APIC
| username            | ---                     | User to configure APIC
| password            | ---                     | Password of the User
| apic_use_proxy      | no                      | If to communicate via proxy
| apic_validate_certs | no                      | If to check SSL Certificate

### Export policy

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| export_policy       | geo_aci_snapshot        | Export policy name
| snap_secrets        | no                      | To include secrets or not

### Import policy

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| import_policy       | geo_aci_rollback        | Import policy name

### Snapshots to action on

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| snapshot_name       | run-2019-11-27T17-59-05 | Snapshot to delete/restore/compare
| snapshot2_name      | run-2019-11-27T17-59-05 | Snapshot to compare

### Backup Action

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| snapshot_action     | create                  | create, list, delete, compare or restore

## Behaviour

```mermaid
graph TD
A[main] --> |validate input parameters| B{policy}

B --> |export policy| C[Create export policy]
B --> |import policy| D[Create import policy]

C --> C1{snapshot_action}
D --> D1{snapshot_action}

C1 --> |create| C2[Trigger export policy]
C2 --> C3[Store a snapshot]
C1 --> |list| C4[List snapshots]
C1 --> |delete| C5[Delete snapshot]

D1 --> |compare| D2[Compare two snapshots]
D1 --> |restore| D3[Trigger import policy]
D3 --> D4[Restore from snapshot]
```

Script will implicitely create new Export or Import policy, if absent.  
Then execution will be switched to one of five possible actions:

- **create** - trigger Export policy to create a snapshot
- **list** - get a list of the snapshots stored on APIC
- **delete** - delete snapshot
- **compare** - compare two snapshots with each other
- **restore** - rollback APIC configuration to specific snapshot

All snapshots are stored on APIC local storage. One can download them manually. For remote storage use role [aci_backup](roles/aci_backup).

Comparison difference is returned in XML format.  
Attribute `status="created|deleted|modified|''"` indicates the difference type.
When `status="modified"` old values are marked by suffix `__ov` and new values are marked by suffix `__nv`  
For example:

```xml
  <... status="modified" toPort__ov="34" fromPort__ov="32" fromPort__nv="27" fromCard="1" toPort__nv="28"/>
```

## Example Playbook

```yaml
---
- name: Snapshot ops
  hosts: [ localhost ]
  gather_facts: no
  vars_files: [ example_vars.yml ]
  tasks:
    - name: Invoke snapshot action
      include_role:
        name: aci_snapshot
      vars:
        snapshot_action: list
```

See more details in playbook file [config_snapshot](playbooks/config_snapshot.yml)

## Playbook usage examples

Create snapshot:

```bash
ansible-playbook playbooks/config_snapshot.yml
```

List snapshots:

```bash
ansible-playbook playbooks/config_snapshot.yml -e snapshot_action=list
```

Delete snapshot:

```bash
ansible-playbook playbooks/config_snapshot.yml -e snapshot_action=delete -e snapshot_name=run-2020-01-13T18-14-07
```

Compare two snapshots:

```bash
ansible-playbook playbooks/config_snapshot.yml -e snapshot_action=compare -e snapshot_name=run-2020-01-13T18-39-58 -e snapshot2_name=run-2020-01-13T17-24-08
```

Restore snapshot:

```bash
ansible-playbook playbooks/config_snapshot.yml -e snapshot_action=restore -e snapshot_name=run-2020-01-13T18-39-58
```

## License

## Author Information

Created by Georgs Muravjovs (georgs.muravjovs@accenture.com)
