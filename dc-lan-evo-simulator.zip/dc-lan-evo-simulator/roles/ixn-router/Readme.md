# ixn-router

Configure IPN routers with connection to the ACI Fabric providers.

## Requirements

Ansible, ipaddr module

## Role Variables

## Behaviour

Script should follow all steps defined in the documentation

## Example Playbook

Sample playbook to update local repository to the remote repository.

## License

Inetrnal Allianz usage only

## Author Information

Created by Tomek Zajac (tomasz.zajac@allianz.com).
