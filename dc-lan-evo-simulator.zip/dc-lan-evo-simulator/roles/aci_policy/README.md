# aci_policy

Deploy ACI fabric policies


## Requirements

Ansible, python-dateutil, pyopenssl


## Role Variables

### APIC Authentication

| Name                | Default value | Comments                        |
|---------------------|---------------|---------------------------------|
| apic_host           | ---           | APIC IP address or URL          |
| apic_username       | ---           | APIC username                   |
| apic_password       | ---           | APIC user password              |
| apic_validate_certs | no            | SSL certificate validation      |

### Other

| Name   | Default value | Comments                                           |
|--------|---------------|----------------------------------------------------|
| action | ---           | deploy - create policies, remove - remove policies |


## Behaviour

```mermaid
graph TD
A[start] --> | |B{action}

B --> |deploy |C[deploy policies]
B --> |remove |D[remove policies]
```



Deploy or remove the following fabric policies as described in role vars file:

  Fabric Policies -> Policies -> Global

    DNS Profiles (default, with providers and domains)


  Fabric Policies -> Policies -> Monitoring

    Fabric Node Controls


  Fabric Policies -> Policies -> Pod

    Date and Time (with NTP servers)
    SNMP


  Fabric Policies -> Policies -> Switch

    Power Supply Redundancy


  Access Policies -> Policies -> Global

    MCP


  Access Policies -> Policies -> Interface

    Link Level
    CDP Interface
    LLDP Interface
    Port Channel
    Port Channel Member
    MCP Interface
    L2 Interface
    Spanning Tree Interface
    Storm Control


  Admin -> External Data Collectors -> Monitoring Destinations

    SNMP


## Example Playbook

Sample playbook to deploy all of the policies listed above.
To remove policies, change variable 'action' to 'remove'.

```yaml
---
- hosts: localhost
  gather_facts: false

  vars:
    aci_host: sandboxapicdc.cisco.com
    action: deploy


  tasks:

    - name: Include vars for our deployment.
      include_vars:
        file: "../data/DEV-fabric.yml"
        name: dc_model_data


    - name: Include credentials
      include_vars:
        file: "../secrets/aci.yml"


    - name: Deploy policies
      include_role:
        name: ../roles/aci_policy
      vars:
        action: deploy

```


## License


## Author Information

