# aci_user

Add user with certificate authentication for APIC controller.

## Requirements

Ansible, python-dateutil, pyopenssl

## Role Variables

```yaml
aci_host: XXX.XXX.XXX.XXX
aci_username: apic_username
aci_password: apic_password
aci_valicate_cert: yes/no
script_user: aci_ansible_user
certfile: "../../aci_ansible.crt"
```

## Behaviour

Script will delete user if user exist then user will be re-created, certificate will be attached.
On the end security domain "all" will be attached to the user and role admin will be set for domain all.

For future code simplification certificate name will be the same as user name.

## Example Playbook

Sample playbook to create user with cerificate authentication. Certificate must be generated before.

openssl req -new -newkeyrsa:1024 -days 36500 -nodes -x509 -keyout aci_ansible.key -out aci_ansible.crt -subj '/CN=aci_ansible/O=Allianz_Technology/C=DE'

```yaml
---
- name: Deploy APIC user with cert auth
  hosts:
    - "localhost"
  gather_facts: no

  vars:
    aci_host: 10.16.254.109
    script_user: aci_ansible
    certfile: "../../aci_ansible.crt"

  tasks:
    - name: deploy user
      include_role:
        name: ../roles/aci_user
      tags: aci_user
```

## License

## Author Information

Created by Tomek Zajac (tomasz.zajac@allianz.com).
