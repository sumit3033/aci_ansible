# aci-switch

Deploy switch Switch and necessary profiles within fabric

```mermaid
graph TD;

    Start-->SwitchesInFabric[Switches deployed in Fabric];
    SwitchesInFabric-->SwitchesToRemove[Generate List of Switches to be removed];
    SwitchesInFabric-->SwitchesToRemain[Generate List of new Switches];
    SwitchesInFabric-->SwitchesToUpdate[Generate List of Switches to be updated];  
    SwitchesToRemain-->Bind[Bind S/N to Node Id];
    SwitchesToRemove-->Decommission;
    SwitchesToUpdate-->Decommission;
    Decommission-->RemovefromCTL[Remove from controller];
    RemovefromCTL-->WaitisRemoved[Wait until is removed];
    WaitisRemoved-->isUpdate
    isUpdate{Replace Switch}-- No -->DASP;
    DASP-->RSIP[Remove switch interface profile];
    RSIP-->RSP[Remove switch profile];
    RSP-->ROOP[Remove OOB];
    ROOP-->RInband[Remove Inband];
    RInband-->End;
    isUpdate{Replace Switch}-- Yes -->Bind[Bind New S/N to NodeId];
    Bind[Bind S/N to NodeId]-->Wait[Wait for OK];
    Wait[Wait for OK]-->IsNew{Is new Node Id ?};
    IsNew-- No -->End;
    IsNew-- Yes -->Inband[Configure Inband];
    Inband-->OOB[Configure OOB];
    OOB-->SP[Create switch profile and add switch selector];
    SP-->SIP[Create Switch Interface Profile];
    SIP-->ASP[Associating an interface selector profile to a switch policy profile]
    ASP-->End;

```

## Requirements

Ansible 2.4
Listify filter

## Role Variables

```yaml
    hostname: '{{ aci_host }}'
    username: '{{ aci_user }}'
    private_key: '{{ aci_user_key }}'
    validate_certs: '{{ apic_validate_certs }}'
    action: deploy # available: deploy, remove, replace
    dc_model_data:
      dc:
        - name: DEV-E2
          region: EMEA
          city: PAR
          pods:
          - number: 1 
            switches:
              - node_id: 101
                ser_num: TEP-1-103
                type: spine
              - node_id: 1001
                ser_num: TEP-1-101
                type: leaf
              - node_id: 1002
                ser_num: TEP-1-102
                type: leaf    
```

## Behaviour

Script will deploy switches based on the input file.
For all switches respective (single as per design) switch profile, switch policy selector profile, interface profile, interface policy selector profile will be created.

## Example Playbook

Sample playbook to deploy switches.

```yaml
---
- name: Deploy ACI switches
  hosts:
    - "localhost"
  gather_facts: no

  vars:
    hostname: '{{ aci_host }}'
    username: '{{ aci_user }}'
    private_key: '{{ aci_user_key }}'
    validate_certs: '{{ apic_validate_certs }}'
    dc_model_data:
      dc:
        - name: DEV-E2
          region: EMEA
          city: PAR
          pods:
          - number: 1
            switches:
              - node_id: 101
                ser_num: TEP-1-103
                type: spine
              - node_id: 1001
                ser_num: TEP-1-101
                type: leaf
              - node_id: 1002
                ser_num: TEP-1-102
                type: leaf

  tasks:
    - name: deploy switches
      include_role:
        name: ../roles/aci-switch
```

## License

## Author Information

Created by Tomek Zajac (tomasz.zajac@allianz.com).
