# aci-domain

Deploy domain, vlan pool and vlan encapsulation  
Types of domains currently supported are:

- Physical
- VMM
- L3 External

## Requirements

Ansible

## Role Variables

### APIC Authentication

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| apic_hostname       | ---                     | IP address or URL of APIC
| apic_username       | ---                     | User to configure APIC
| apic_password       | ---                     | Password of the User
| apic_use_proxy      | no                      | If to communicate via proxy
| apic_validate_certs | no                      | If to check SSL Certificate

### Vlan Pool and Domain input parameters

| Name                | Default value           | Comments
|---------------------|-------------------------|----------
| domain_type         | ---                     | phys, vmm, l3dom, ixn
| allocation          | static                  | static, dynamic
| zone                | ---                     | (optional) TR, NTR
| description         | ---                     | (optional) INBAND, IXN, etc.
| vmm_provider        | ---                     | (optional) vmware, redhat, etc.
| vlan_from           | ---                     | vlan pool starts from
| vlan_to             | ---                     | vlan pool ends to
| state               | ---                     | present, absent

## Behaviour

Script will create Vlan Pool and Domain global policies.  
On the beginning vlan pool and respective vlan encapsulation block is created.
Then depends from the domain type respective domain is created.
On the end vlan pool is binded to the domain.
Naming convention is defined in the jinja templates in templates/naming folder

## Example Playbook

Sample playbook to deploy domain with vlan pool and ancapsulation block

```yaml
---
- name: Deploy full domain
  hosts: [ localhost ]
  gather_facts: no

  vars:
    apic_hostname: "{{ apic_host }}"
    apic_username: "{{ username }}"
    apic_password: "{{ password }}"
    apic_use_proxy: no
    apic_validate_certs: no
    state: present # available: absent , present
    description: description  
    vlan_from: 10
    vlan_to: 10
    allocation: static # available: static , dynamic
    domain_type: phys # available phys, vmm , l3dom, l2dom
    zone: TR # available: tr, ntr ; field is optional  

  tasks:

    - name: Include necessary data
      include_vars:
        file: "../../vault.yml"

    - name: deploy switches
      include_role:
        name: ../roles/aci_domain
```

## License

MSU

## Author Information

Created by Tomek Zajac (tomasz.zajac@allianz.com).
