# DC LAN EVO Simulator Bootstrap

## Bootstrap should contain following tasks

- configure DNS
- configure NTP
- register switches
- deploy pods
- deploy pods profiles
- configure switch profiles
- configure interface profiles
- configure IPX (Inter-pod and Inter-site)
- configure route reflectors
- configure pbr
- connection to the core
- ... and many more ...
- ... to be discussed ...

## To be clarified over next sprint

- data structure
- how to fulfill requirement to keep naming convention in single place (currently in templates/naming)
- where to store encrypted credentials and certificates
- how to store information about customer hardware deployed in DC and used for many customer applications

Sample input file for Fabric and Application in data/ folder

Sample script using data (with listify)  and naming convention templates (jinja2) in playbooks/application.yml
